#!/usr/bin/env python3
"""生成完整 Skill 发布包；只检查打包依赖，不证明教学行为有效。"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parents[1]
skill = root / 'ai-collaboration-coach'
main = (skill / 'SKILL.md').read_text(encoding='utf-8')
version = re.search(r'版本[：:]\s*(\d+\.\d+\.\d+)', main)
if not version:
    raise SystemExit('缺少有效版本号')
for path in skill.rglob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('#'):
            continue
        target = target.split('#')[0]
        if target and not (path.parent / target).resolve().exists():
            raise SystemExit(f'缺少引用文件：{path.name} -> {target}')
for item in json.loads((skill / 'assets/resource-manifest.json').read_text()):
    asset = skill / 'assets' / item['file']
    if asset.stat().st_size != item['bytes']:
        raise SystemExit(f'资源大小不一致：{asset.name}')
out = root / 'dist'
out.mkdir(exist_ok=True)
archive = out / 'ai-collaboration-coach.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in sorted(skill.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            z.write(path, path.relative_to(root).as_posix())
    for name in ['使用说明_中文版.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md']:
        z.write(root / name, name)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:
        raise SystemExit('ZIP完整性检查失败')
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(out / 'SHA256SUMS.txt').write_text(f'{digest}  {archive.name}\n', encoding='utf-8')
print(f'v{version.group(1)}: {archive.name} ({archive.stat().st_size} bytes)')
